# Submitify
Submitify plugin for codeforces- which allows us to submit code from Problem page itself.


#### GOOGLE CHROME - INSTALLATION

- Download this repository.
- Extract the zip files. 
- Go to chrome://extensions/ from the browser. 
- Turn on Developer mode.
- Click on load unpacked and **select the extracted folder having the manifest.json file.**


#### FIREFOX - INSTALLATION

- Download from here : https://addons.mozilla.org/en-US/firefox/addon/submitify/

#### OPERA - INSTALLATION

- Download this repository.
- Extract the zip files. 
- Open the .crx file in the Opera folder using Opera browser.
